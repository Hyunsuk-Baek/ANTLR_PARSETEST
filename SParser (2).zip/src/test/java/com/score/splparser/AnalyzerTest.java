package com.score.splparser;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.score.sqlparser.SqlAnalyzer;
import com.score.sqlparser.model.ColumnReference;
import com.score.sqlparser.model.SqlResult;

public class AnalyzerTest {
	@Test
	void analyzer() {
		SqlAnalyzer analyzer = new SqlAnalyzer();
		SqlResult result = analyzer.analyze("select T1.A from db0.T2 AS T1 where T1.C = 'aaa'");
		
		for (ColumnReference col : result.getRefColumnList()) {
			assertEquals(col.getDatabaseName(), "db0");
			assertEquals(col.getTableName(), "T2");
		}
	}
}
