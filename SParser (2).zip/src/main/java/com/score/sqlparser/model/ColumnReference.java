package com.score.sqlparser.model;

public class ColumnReference {
	String databaseName;
	String tableName;
	String columnName;

	public ColumnReference(String columnName) {
		this.columnName = columnName;
	}

	public ColumnReference(String columnName, String tableName) {
		this.columnName = columnName;
		this.tableName = tableName;
	}

	public ColumnReference(String columnName, TableReference tableRef) {
		this.columnName = columnName;
		this.tableName = tableRef.getTableName();
		this.databaseName = tableRef.getDatabaseName();
	}

	
	public String getDatabaseName() {
		return databaseName;
	}

	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

}
