package com.score.sqlparser.model;

import java.util.ArrayList;
import java.util.List;

public class SqlResult {

	List<ColumnReference> refColumnList = new ArrayList<ColumnReference>();

	public List<ColumnReference> getRefColumnList() {
		return refColumnList;
	}

	public void add(SqlResult result) {
		refColumnList.addAll(result.getRefColumnList());
	}

	public void add(ColumnReference column) {
		refColumnList.add(column);
	}
}
