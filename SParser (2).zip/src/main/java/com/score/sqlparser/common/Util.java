package com.score.sqlparser.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import com.score.sqlparser.model.ColumnReference;
import com.score.sqlparser.model.SqlResult;

public class Util {

	public void printSQLResult(SqlResult traverseResult) {
		if (traverseResult.getRefColumnList() != null) {
			for (ColumnReference column : traverseResult.getRefColumnList()) {
				if (column.getColumnName() == null)
					continue;

				if (column.getDatabaseName() != null) {
					System.err.print(column.getDatabaseName() + ".");
				}
				if (column.getTableName() != null) {
					System.err.print(column.getTableName() + ".");
				}
				System.err.print(column.getColumnName() + "\n");
			}
		}
	}
	/**
	 * Search the given file (or folder) using the ClassPath
	 * 
	 * @param fileName file name or folder name
	 * @return
	 */
	public File getFileByClassPath(final String fileName) {
		final URL url = Util.class.getResource(fileName);
		if (url != null) {
			URI uri = null;
			try {
				uri = url.toURI();
			} catch (final URISyntaxException e) {
				throw new RuntimeException("Cannot convert URL to URI (file '" + fileName + "')");
			}
			return new File(uri);
		} else {
			throw new RuntimeException("File '" + fileName + "' not found");
		}
	}

	/**
	 * Get input stream for file writing.
	 * 
	 * @param filename File name
	 * @return Input stream
	 */
	public InputStream getInputStream(final String filename) {
		try {
			final File file = new File(filename);
			final InputStream in = new FileInputStream(file);
			return in;
		} catch (final FileNotFoundException e) {
			System.err.println(e.getMessage());
			System.err.println(e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Return output stream for file writing and create directory if not exists.
	 * 
	 * @param filename Filename
	 * @return output stream
	 */
	public OutputStream getOutputStream(final String filename) {
		try {

			final String path = filename.substring(0, filename.lastIndexOf(File.separatorChar));
			final File dir = new File(path);
			dir.mkdirs();

			final File file = new File(filename);
			return new FileOutputStream(file);

		} catch (final Exception e) {
			System.err.println(e.getMessage());
			System.err.println(e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Read input stream and return content
	 * 
	 * @param is Input stream
	 * @return content
	 */
	public String read(final InputStream is) {
		BufferedReader br = null;
		final StringBuilder sb = new StringBuilder();

		String line;
		try {

			br = new BufferedReader(new InputStreamReader(is));
			boolean isFirst = true;
			while ((line = br.readLine()) != null) {
				if (isFirst) {
					isFirst = false;
				} else {
					sb.append("\n");
				}
				sb.append(line);
			}

		} catch (final IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (final IOException e) {
					e.printStackTrace();
				}
			}
		}

		return sb.toString();
	}

	/**
	 * Write lines to a output stream.
	 * 
	 * @param lines Lines
	 * @param os    Output stream
	 */
	public void write(final List<String> lines, final OutputStream os) {
		BufferedWriter bw = null;

		bw = new BufferedWriter(new OutputStreamWriter(os));

		try {
			boolean isFirst = true;
			for (final String line : lines) {
				if (isFirst) {
					isFirst = false;
				} else {
					bw.write("\n");
				}
				bw.write(line);
			}
			bw.close();
		} catch (final IOException e) {
			System.err.println(e.getMessage());
			System.err.println(e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Write content to a output stream.
	 * 
	 * @param content Content
	 * @param os      Output stream
	 */
	public void write(final String content, final OutputStream os) {
		BufferedWriter bw = null;

		bw = new BufferedWriter(new OutputStreamWriter(os));

		try {
			if (content != null) {
				bw.write(content);
			}
			bw.close();
		} catch (final IOException e) {
			System.err.println(e.getMessage());
			System.err.println(e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Format name from SQL file.
	 * 
	 * @param sqlName Name in SQL file
	 * @return name
	 */
	public String unformatSqlName(final String sqlName) {
		if (sqlName == null) {
			return null;
		}
		String name = sqlName;
		// escape character : "
		if (name.length() >= 2) {
			if ((name.charAt(0) == '"') && (name.charAt(name.length() - 1) == '"')) {
				name = name.substring(1, name.length() - 1);
			}
		}
		// escape character : `
		if (name.length() >= 2) {
			if ((name.charAt(0) == '`') && (name.charAt(name.length() - 1) == '`')) {
				name = name.substring(1, name.length() - 1);
			}
		}
		return name;
	}

	public List<String> getSqlQuerys(final String content) {
		final List<String> querys = new ArrayList<String>();

		int posStart = getPosStartQuery(content, 0);
		int posEnd = getPosEndQuery(content, posStart);
		while ((posStart != -1) && (posStart < content.length()) && (posEnd < content.length())) {
			final String query = content.substring(posStart, posEnd);
			querys.add(query);

			if ((posEnd + 1) >= content.length()) {
				posStart = -1;
			} else {
				posStart = getPosStartQuery(content, posEnd + 1);
				posEnd = getPosEndQuery(content, posStart);
			}
		}

		return querys;
	}

	private int getPosStartQuery(final String content, int pos) {
		boolean inLineComment = false;
		boolean inMultiLineComment = false;
		boolean inStringValue = false;

		while (pos < content.length()) {
			final char character = content.charAt(pos);
			if (character == '/') {
				if (!inStringValue && !inLineComment && !inMultiLineComment) {
					if (((pos + 1) < content.length()) && (content.charAt(pos + 1) == '*')) {
						inMultiLineComment = true;
						pos = pos + 2;
						continue;
					}
				}
			}
			if (character == '*') {
				if (!inStringValue && !inLineComment && inMultiLineComment) {
					if (((pos + 1) < content.length()) && (content.charAt(pos + 1) == '/')) {
						inMultiLineComment = false;
						pos = pos + 2;
						continue;
					}
				}
			}
			if (character == '"') {
				if (!inLineComment && !inMultiLineComment) {
					inStringValue = !inStringValue;
				}
			}
			if (character == '-') {
				if (!inStringValue && !inLineComment && !inMultiLineComment) {
					if (((pos + 1) < content.length()) && (content.charAt(pos + 1) == '-')) {
						inLineComment = true;
						pos = pos + 2;
						continue;
					}
				}
			}
			if ((character == '\n') || (character == '\r')) {
				if (inLineComment) {
					inLineComment = false;
				}
			}
			if (((character >= 'a') && (character <= 'z')) || ((character >= 'A') && (character <= 'Z'))) {
				if (!inStringValue && !inLineComment && !inMultiLineComment) {
					break;
				}
			}
			pos++;
		}

		return pos;
	}

	/**
	 * Return the position of the end of the current SQL query.
	 * 
	 * @param content SQL content
	 * @param pos     Current position in the SQL content
	 * @return Position of the end of the current SQL query
	 */
	private int getPosEndQuery(final String content, int pos) {

		boolean inLineComment = false;
		boolean inMultiLineComment = false;
		boolean inStringValue = false;

		while (pos < content.length()) {
			final char character = content.charAt(pos);
			if (character == '/') {
				if (!inStringValue && !inLineComment && !inMultiLineComment) {
					if (((pos + 1) < content.length()) && (content.charAt(pos + 1) == '*')) {
						inMultiLineComment = true;
						pos = pos + 2;
						continue;
					}
				}
			}
			if (character == '*') {
				if (!inStringValue && !inLineComment && inMultiLineComment) {
					if (((pos + 1) < content.length()) && (content.charAt(pos + 1) == '/')) {
						inMultiLineComment = false;
						pos = pos + 2;
						continue;
					}
				}
			}
			if (character == '"') {
				if (!inLineComment && !inMultiLineComment) {
					inStringValue = !inStringValue;
				}
			}
			if (character == '-') {
				if (!inStringValue && !inLineComment && !inMultiLineComment) {
					if (((pos + 1) < content.length()) && (content.charAt(pos + 1) == '-')) {
						inLineComment = true;
						pos = pos + 2;
						continue;
					}
				}
			}
			if ((character == '\n') || (character == '\r')) {
				if (inLineComment) {
					inLineComment = false;
				}
			}
			if (character == ';') {
				if (!inStringValue && !inLineComment && !inMultiLineComment) {
					break;
				}
			}
			pos++;
		}

		return pos;
	}
}
