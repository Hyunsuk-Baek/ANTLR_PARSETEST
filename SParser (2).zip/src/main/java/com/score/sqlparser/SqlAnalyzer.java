package com.score.sqlparser;

import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;

import com.restlet.sqlimport.parser.SqlLexer;
import com.restlet.sqlimport.parser.SqlParser;
import com.score.sqlparser.common.Util;
import com.score.sqlparser.model.SqlResult;
import com.score.sqlparser.visitor.SqlStmtListVisitor;

public class SqlAnalyzer {
	public SqlResult analyze(String sqlQuery) {
		final ANTLRInputStream inputStream = new ANTLRInputStream(sqlQuery);

		final SqlLexer lexer = new SqlLexer(inputStream);
		final SqlParser parser = new SqlParser(new CommonTokenStream(lexer));

		SqlStmtListVisitor sqlStmtListVisitor = new SqlStmtListVisitor();
		SqlResult traverseResult = sqlStmtListVisitor.visit(parser.sql_stmt_list());

		Util util = new Util();
		util.printSQLResult(traverseResult);
		return traverseResult;
	}

	
}
