package com.score.sqlparser;

public class AnalyzerMain {

	public static void main(String[] args) {
		SqlAnalyzer analyzer = new SqlAnalyzer();
		
		analyzer.analyze("select T1.A from db0.T2 AS T1 where T1.C = 'aaa'");
		System.out.println("===");
//		
		analyzer.analyze("select T1.A, B from DB0.T2 AS T1");
		analyzer.analyze("select T1.A, B from T2 AS T1");
		analyzer.analyze("select T1.A from T2 AS T1");
		analyzer.analyze("select A from T1;select B from T2;select T1.A from T2 AS T1");
	}
}
