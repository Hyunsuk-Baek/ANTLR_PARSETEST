package com.score.sqlparser.visitor;

import com.restlet.sqlimport.parser.SqlBaseVisitor;
import com.restlet.sqlimport.parser.SqlParser.Sql_stmtContext;
import com.restlet.sqlimport.parser.SqlParser.Sql_stmt_listContext;
import com.score.sqlparser.model.SqlResult;

public class SqlStmtListVisitor extends SqlBaseVisitor<SqlResult> {

	@Override
	public SqlResult visitSql_stmt_list(Sql_stmt_listContext ctx) {
		SqlResult result = new SqlResult();

		for (int i = 0; i < ctx.getChildCount(); i++) {
			Sql_stmtContext stmtCtx = ctx.sql_stmt(i);
			if (stmtCtx != null) {
				result.add(visitSql_stmt(stmtCtx));
			}
		}

		return result;
	}

	@Override
	public SqlResult visitSql_stmt(Sql_stmtContext ctx) {
		SqlResult result = new SqlResult();
		if (ctx.factored_select_stmt() != null || ctx.select_stmt() != null || ctx.simple_select_stmt() != null) {
			result.add(ctx.factored_select_stmt().accept(new SqlSelectStmtVisitor()));
		}

		return result;
	}
}
