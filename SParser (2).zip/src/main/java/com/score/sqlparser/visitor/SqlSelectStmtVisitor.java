package com.score.sqlparser.visitor;

import java.util.ArrayList;
import java.util.List;

import com.restlet.sqlimport.parser.SqlBaseVisitor;
import com.restlet.sqlimport.parser.SqlParser.ExprContext;
import com.restlet.sqlimport.parser.SqlParser.Factored_select_stmtContext;
import com.restlet.sqlimport.parser.SqlParser.Result_columnContext;
import com.restlet.sqlimport.parser.SqlParser.Select_coreContext;
import com.restlet.sqlimport.parser.SqlParser.Select_stmtContext;
import com.restlet.sqlimport.parser.SqlParser.Simple_select_stmtContext;
import com.restlet.sqlimport.parser.SqlParser.Table_or_subqueryContext;
import com.score.sqlparser.model.ColumnReference;
import com.score.sqlparser.model.SqlResult;
import com.score.sqlparser.model.TableReference;

public class SqlSelectStmtVisitor extends SqlBaseVisitor<SqlResult> {

	@Override
	public SqlResult visitSimple_select_stmt(Simple_select_stmtContext ctx) {
		return super.visitSimple_select_stmt(ctx);
	}

	@Override
	public SqlResult visitFactored_select_stmt(Factored_select_stmtContext ctx) {
		return visitSelect_core(ctx.select_core(0));
	}

	@Override
	public SqlResult visitSelect_stmt(Select_stmtContext ctx) {
		return super.visitSelect_stmt(ctx);
	}

	@Override
	public SqlResult visitSelect_core(Select_coreContext ctx) {
		SqlResult result = new SqlResult();

		// from
		List<TableReference> tables = new ArrayList<TableReference>();
		for (Table_or_subqueryContext tableOrSubquery : ctx.table_or_subquery()) {
			String aliasName = null;
			if (tableOrSubquery.table_alias() != null) {
				aliasName = tableOrSubquery.table_alias().getText();
			}

			String databaseName = null;
			if (tableOrSubquery.database_name() != null) {
				databaseName = tableOrSubquery.database_name().getText();
			}

			tables.add(new TableReference(tableOrSubquery.table_name().getText(), databaseName, aliasName));
		}

		// where
		int whereIdx = ctx.children.indexOf(ctx.K_WHERE());
		for (int i = whereIdx + 1; i < ctx.getChildCount(); i++) {
			if (ctx.getChild(i).getPayload() instanceof ExprContext) {
				ExprContext whereExpr = (ExprContext) ctx.getChild(i).getPayload();
				if (analyzeExprForWhere(whereExpr, tables) == null) {
					break;
				}
				result.add(analyzeExprForWhere(whereExpr, tables));

			} else {
				break;
			}
		}

		// result_column
		for (Result_columnContext resultColumn : ctx.result_column()) {
			result.add(analyzeResult_column(resultColumn, tables));
		}
		return result;
	}

	private SqlResult analyzeExprForWhere(ExprContext whereExpr, List<TableReference> tables) {
		SqlResult result = new SqlResult();
		if (whereExpr.expr() == null) {
			return null;
		}
		for (ExprContext expr : whereExpr.expr()) {
			if (expr.literal_value() == null) {
				result.add(analyzeExprForResultColumn(expr, tables));
			}
		}
//		for (int i = 0; i < whereExpr.getChildCount(); i++) {
//			if (whereExpr.getChild(i).getPayload() instanceof ExprContext) {
//				result.add(analyzeExprForResultColumn((ExprContext) whereExpr.getChild(i).getPayload(), tables));
//			}
//		}
		return result;
	}

	private ColumnReference analyzeResult_column(Result_columnContext resultColumn, List<TableReference> tables) {
		ColumnReference column = null;
		if (resultColumn.expr() != null && resultColumn.expr().literal_value() == null) {
			// expr
			column = analyzeExprForResultColumn(resultColumn.expr(), tables);
		} else if (resultColumn.table_name() != null) {
			// table_name.*
			TableReference tableRef = findTableReference(resultColumn.table_name().getText(), tables);
			column = new ColumnReference("*", tableRef.getTableName());
		} else {
			// *
			column = tables.isEmpty() ? new ColumnReference("*")
					: new ColumnReference("*", tables.get(0).getTableName());
		}

		return column;
	}

	private ColumnReference analyzeExprForResultColumn(ExprContext expr, List<TableReference> tables) {
		ColumnReference column = null;
		TableReference tableRef = null;
		if (expr.table_name() != null) {
			tableRef = findTableReference(expr.table_name().getText(), tables);
		} else if (!tables.isEmpty()) {
			tableRef = tables.get(0);
		}

		if (tableRef != null) {
			column = new ColumnReference(expr.column_name().getText(), tableRef);
		} else {
			column = new ColumnReference(expr.getText());
		}

		return column;
	}

	private TableReference findTableReference(String tableName, List<TableReference> tables) {
		for (TableReference table : tables) {
			if (tableName.equals(table.getTableName())) {
				return table;
			}
		}
		for (TableReference table : tables) {
			if (tableName.equals(table.getAliasName())) {
				return table;
			}
		}
		return null;
	}

}
