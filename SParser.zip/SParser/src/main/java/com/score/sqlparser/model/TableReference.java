package com.score.sqlparser.model;

public class TableReference {

	String tableName;
	String databaseName;
	String aliasName;

	public TableReference(String tableName) {
		this.tableName = tableName;
	}

	public TableReference(String tableName, String databaseName, String aliasName) {
		this.tableName = tableName;
		this.databaseName = databaseName;
		this.aliasName = aliasName;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public String getDatabaseName() {
		return databaseName;
	}

	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}

}
